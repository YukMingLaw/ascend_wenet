#!/bin/bash
rm -rf {lm,util,util/double-conversion}/*.o bin/{query,build_binary}
